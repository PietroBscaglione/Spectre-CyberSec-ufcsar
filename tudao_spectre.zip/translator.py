import requests
from pwn import *
import os
context.arch = 'amd64'

def reg_helper(reg1, reg2):
    return (reg2 & 0x7) | ((reg1 & 0x7) << 3)

class Translator:
    def __init__(self):
        self.content = b''
        self.count = 0
    
    def start(self, cont =b''):
        self.content += cont
        return

    def getloop(self):
        return self.count

    def complete(self):
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x00'
        ulen = len(self.content)
        self.content = p64(ulen) + self.content
    

    def movsxd(self, rx, ryd):
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x01'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([0xc0 | reg_helper(ryd, rx)])
        self.count += 2
    
    def add(self, rx, ry):
        # \x02
        # add rx, ry
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x02'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([0xc0 | reg_helper(ry, rx)])
        self.count += 2
    
    def sub(self, rx, ry):
        # \x03
        # sub rx, ry
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x03'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([0xc0 | reg_helper(ry, rx)])
        self.count += 2
    
    def uand(self, rx, ry):
        # \x04
        # and rx, ry
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x04'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([0xc0 | reg_helper(ry, rx)])
        self.count += 2
    
    def shl(self, rx, ryd):
        # \x05
        # mov cl, ryd
        # shl rx, cl
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x05'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([0xc0 | reg_helper(ryd, rx)])
        self.count += 2

    def shr(self, rx, ryd):
        # \x06
        # mov cl, ryd
        # shr rx, cl
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x06'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([0xc0 | reg_helper(ryd, rx)])
        self.count += 2

    def mov(self, rx, ry):
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x07'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([0xc0 | reg_helper(ry, rx)])
        self.count += 2

    def movc(self, rx, const):
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x08'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([0xc0 | reg_helper(0, rx)])
        self.content += p32(const)
        self.count += 6
    


    def load(self, rx, ryd):
        # mov eax, ryd
        # mov rx, [0x414100000000 + rax * 1]
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x09'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([0xc0 | reg_helper(ryd, rx)])
        self.count += 2
    
    def store(self, rx, ryd):
        # mov eax, rxd
        # mov [rdi + rax * 1], ry
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x0a'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([0xc0 | reg_helper(ryd, rx)])
        self.count += 2
    
    def bc(self, rchoice = 0):
        # input r8d, r9d, r10d, r11d
        # output r8
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x0b'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([rchoice])
        self.count += 2
    
    def time(self, rchoice = 0):
        # input r8d, r9d, r10d, r11d
        # output r8
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x0b'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([rchoice + 8])
        self.count += 2
    
    def builtin(self, choice):
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x0b'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([choice])

    def loop(self, count, offset, reg = 0):
        # --- ALTERAÇÃO AQUI ---
        self.content += b'\x0c'
        # --- ALTERAÇÃO AQUI ---
        self.content += bytes([reg * 0x8])
        self.content += p32(count)
        self.content += p32(offset)
        self.count += 10

    def go(self):
        token = keyget()
        filename = 'tmptmp'
        os.system('touch ' + filename)
        # --- ALTERAÇÃO AQUI (modo 'wb' para write binary) ---
        open('tmptmp', 'wb').write(self.content)
        result = upload(token, filename)
        os.system('rm ' + filename)
        # --- ALTERAÇÃO AQUI (split em bytes) ---
        result = result.split(b'\n')
        result = result[1:-1]
        r = []
        for tmp1 in result:
            # --- ALTERAÇÃO AQUI (split em bytes) ---
            tmp1 = tmp1.split(b' ')
            tmp1 = tmp1[:-1]
            for tmp2 in tmp1:
                r.append(int(tmp2, 16))
        return r 



# def upload(token,filename):
#     url = 'http://spectre.pwni.ng:4000'
#     files = {'script': open(filename, 'rb')}
#     data = {'pow':token}
#     r = requests.post(url, files=files, data=data)
#     res = r.content
#     pos = res.find('<pre style="background-color: white; margin: 2rem 0; padding: 2rem 0">') + len('<pre style="background-color: white; margin: 2rem 0; padding: 2rem 0">')
#     res = res[pos:]
#     pos = res.find('</pre>')
#     res = res[:pos]
#     return res

def upload(token,filename):
    url = 'http://spectre.pwni.ng:4000'
    files = {'script': open(filename, 'rb')}
    data = {'pow':token}
    r = requests.post(url, files=files, data=data,  allow_redirects = False)
    url = r.headers['Location']
    while True:
        r = requests.get(url)
        res = r.content
        # --- ALTERAÇÃO AQUI (find em bytes) ---
        if(res.find(b'Processing')==-1):
            break
    # --- ALTERAÇÃO AQUI (find em bytes) ---
    b_pre_tag = b'<pre style="background-color: white; margin: 2rem 0; padding: 2rem 0">'
    pos = res.find(b_pre_tag) + len(b_pre_tag)
    res = res[pos:]
    # --- ALTERAÇÃO AQUI (find em bytes) ---
    pos = res.find(b'</pre>')
    res = res[:pos]
    return res



def keyget():
    # --- ALTERAÇÃO AQUI (modo 'r' explícito) ---
    keys = open('./keys.txt', 'r').read()
    keys = keys.split('\n')[:-1]
    result = keys.pop()
    f = open('./keys.txt', 'w')
    for i in keys:
        f.write(i)
        f.write('\n')
    f.close()
    return result
